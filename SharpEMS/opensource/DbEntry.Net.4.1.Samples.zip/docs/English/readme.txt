
                             DbEntry.Net

DbEntry.Net is a lightweight Object Relational Mapping (ORM) 
database access compnent for .Net 2.0. It has clearly and 
easily programing interface for ORM and sql directly, and 
supoorted Access, Sql Server, MySql, SQLite.

Please view Samples code to get the usage of this compnent.

It tested on MS Sql Server 2000, MS Sql Server 2005, MS Access 
2003, MySql 5, SQLite 3, Firebird 2.0.3 and Oracle 10g express.

