using System;

namespace OrmCommon
{
    [Serializable]
	public enum UserRole
	{
		Manager,
		Worker,
		Client
	}
}
