
using System;

namespace Common
{
    [Serializable]
	public enum UserRole
	{
		Manager,
		Worker,
		Client
	}
}
