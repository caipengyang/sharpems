
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
DbEntry.Net is a lightweight Object Relational Mapping (ORM) 
database access compnent for .Net 4.0. It has clearly and 
easily programing interface for ORM and sql directly, and 
supoorted Access, Sql Server, MySql, SQLite, Firebird and
Oracle.

It also provide a Ruby On Rails style MVC framework.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
llf's studio:	http://llf.hanzify.org
liang lifeng:	liang_li_feng@tom.com

DbEntry CodePlex Url:
http://www.codeplex.com/dbentry
DbEntry SourceForge Url:
http://sourceforge.net/projects/dbentry/
